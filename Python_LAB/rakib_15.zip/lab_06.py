def invert_dictionary(input_dict):
    inverted_dict = {}

    for key, value in input_dict.items():
        if value not in inverted_dict:
            inverted_dict[value] = [key]
        else:
            inverted_dict[value].append(key)

    return inverted_dict


input_dict = {}
num_entries = int(input("Enter the number of entries in the dictionary: "))
for _ in range(num_entries):
    key = input("Enter a key: ")
    value = input("Enter its value: ")
    input_dict[key] = value

inverted_dict = invert_dictionary(input_dict)

