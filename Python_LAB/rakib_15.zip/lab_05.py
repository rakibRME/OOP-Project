def filter_even_numbers(dictionary):
    even_numbers_dict = {}

    for key, value in dictionary.items():
        even_values = [num for num in value if num % 2 == 0]
        even_numbers_dict[key] = even_values

    return even_numbers_dict

# Take user input for the sample input dictionaries
input_dict = {}
num_entries = int(input("Enter the number of entries in the dictionary: "))

for i in range(num_entries):
    key = input("Enter the key: ")
    values = list(map(int, input(f"Enter the values for '{key}' (comma-separated): ").split(',')))
    input_dict[key] = values

# Filter even numbers from the dictionary
output_dict = filter_even_numbers(input_dict)

# Print the filtered dictionary
print("Filter even numbers from given dictionary values:")
print("Sample Output:")
print(output_dict)
