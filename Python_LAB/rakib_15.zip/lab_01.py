user_data = {}
key = input("Enter name: ")
value = float(input("Enter CGPA: "))
user_data[key] = value
print("Do you want to Enter another record Press 'y' if yes: ")
print("Do you want to Enter another record Press 'n' if no: ")
ch = input()
while ch == 'y':
    key = input("Enter name: ")
    value = float(input("Enter CGPA: "))
    user_data[key] = value
    print("Do you want to Enter another record Press 'y' if yes: ")
    print("Do you want to Enter another record Press 'n' if no: ")
    ch = input()
    if ch == 'y':
        continue
    else:
        break
print(user_data)

