lst = []
while True:
    count = input("Number of values (or type 'STOP' to stop): ")
    if count == "STOP":
        break
    count = int(count)
    for i in range(count):
        num = input("Enter number: ")
        if num == "STOP":
            break
        else:
            lst.append(int(num))

    if count != 0:
        lst.sort()
        if lst[count - 1] - lst[0] < count:
            print("UB Jumper")
        else:
            print("Not UB Jumper")
    else:
        print("Count cannot be zero.")
