month_days = {
    "January": 31,
    "February": 28,
    "March": 31,
    "April": 30,
    "May": 31,
    "June": 30,
    "July": 31,
    "August": 31,
    "September": 30,
    "October": 31,
    "November": 30,
    "December": 31
}


usr_input = input("Enter the Month: ")
print("a) Days in the {} is {}".format(usr_input, month_days[usr_input]))

keys_list = list(month_days.keys())
print(sorted(keys_list))

keys_list_31 = []
for k in month_days:
    if month_days[k] == 31:
        keys_list_31.append(k)
print(keys_list_31)

sorted_by_value = sorted(month_days.items(), key=lambda item: item[1])
print(sorted_by_value)
