count = {}
while True:
    num = input("Enter number (or type 'SHESH' to stop): ")
    if num == "shesh":
        break
    else:
        num = int(num)
        if num in count:
            count[num] += 1
        else:
            count[num] = 1

for num, n in count.items():
    print(f"{num}- {n} times")

